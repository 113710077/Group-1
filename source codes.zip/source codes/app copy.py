import os
from flask import Flask, render_template, request, redirect, url_for, flash, session
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with your own secret key

# Ensure chart output directory exists
CHART_DIR = os.path.join('static', 'charts')
if not os.path.exists(CHART_DIR):
    os.makedirs(CHART_DIR)


def analyze_data(df):
    df['Total'] = df[['Math', 'Science', 'English']].sum(axis=1)
    df['Average'] = df[['Math', 'Science', 'English']].mean(axis=1)
    df['Status'] = np.where(df['Average'] >= 35, 'Pass', 'Fail')

    class_avg = df[['Math', 'Science', 'English']].mean().to_dict()
    pass_count = df['Status'].value_counts().get('Pass', 0)
    fail_count = df['Status'].value_counts().get('Fail', 0)
    top_n = df.sort_values(by='Average', ascending=False).head(5).to_dict(orient='records')
    top_scorer_row = df.loc[df['Average'].idxmax()] if not df.empty else None

    if top_scorer_row is not None:
        top_scorer_row = top_scorer_row.to_dict()

    return df, class_avg, pass_count, fail_count, top_n, top_scorer_row

def create_charts(df):
    charts = {}

    plt.figure(figsize=(8, 5))
    df.set_index('Name')[['Math', 'Science', 'English']].plot(kind='bar', rot=45)
    plt.title('Marks per Subject per Student')
    plt.ylabel('Marks')
    plt.tight_layout()
    bar_chart_path = os.path.join(CHART_DIR, 'bar_chart.png')
    plt.savefig(bar_chart_path)
    plt.close()
    charts['bar_chart'] = 'charts/bar_chart.png'

    status_counts = df['Status'].value_counts()
    plt.figure(figsize=(6, 6))
    plt.pie(status_counts, labels=status_counts.index, autopct='%1.1f%%', startangle=90, colors=['#28a745', '#dc3545'])
    plt.title('Pass/Fail Distribution')
    plt.tight_layout()
    pie_chart_path = os.path.join(CHART_DIR, 'pie_chart.png')
    plt.savefig(pie_chart_path)
    plt.close()
    charts['pie_chart'] = 'charts/pie_chart.png'

    plt.figure(figsize=(8, 5))
    subjects = ['Math', 'Science', 'English']
    averages = [df[sub].mean() for sub in subjects]
    plt.plot(subjects, averages, marker='o', linestyle='-', color='blue')
    plt.title('Average Performance Across Subjects')
    plt.ylim(0, 100)
    plt.grid(True)
    plt.tight_layout()
    line_chart_path = os.path.join(CHART_DIR, 'line_chart.png')
    plt.savefig(line_chart_path)
    plt.close()
    charts['line_chart'] = 'charts/line_chart.png'

    return charts


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if username == 'admin' and password == 'admin123':  # Dummy auth
            session['logged_in'] = True
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials.', 'danger')
            return redirect(url_for('login'))

    return render_template('login.html')


@app.route('/', methods=['GET', 'POST'])
def dashboard():
    if not session.get('logged_in'):
        return redirect(url_for('login'))

    table_html = None
    top_scorer = None
    top_students = None
    charts = {}
    pass_count = 0
    fail_count = 0

    if request.method == 'POST':
        if 'file' in request.files and request.files['file'].filename != '':
            file = request.files['file']
            if not file.filename.endswith('.csv'):
                flash('Please upload a valid CSV file.', 'danger')
                return redirect(url_for('dashboard'))

            try:
                df = pd.read_csv(file)
                required_cols = {'Name', 'Math', 'Science', 'English'}
                if not required_cols.issubset(set(df.columns)):
                    flash(f'CSV must contain columns: {required_cols}', 'danger')
                    return redirect(url_for('dashboard'))

                df = df[list(required_cols)]
            except Exception as e:
                flash(f'Error processing CSV: {e}', 'danger')
                return redirect(url_for('dashboard'))

        elif request.form.get('submit_manual'):
            names = request.form.getlist('name')
            math_marks = request.form.getlist('math')
            science_marks = request.form.getlist('science')
            english_marks = request.form.getlist('english')

            if len(names) < 5:
                flash('Please enter at least 5 students.', 'danger')
                return redirect(url_for('dashboard'))

            data = []
            try:
                for i in range(len(names)):
                    m = int(math_marks[i])
                    s = int(science_marks[i])
                    e = int(english_marks[i])
                    name = names[i].strip()
                    if not name:
                        continue
                    data.append({'Name': name, 'Math': m, 'Science': s, 'English': e})
                df = pd.DataFrame(data)
                if df.empty:
                    flash('No valid student data entered.', 'danger')
                    return redirect(url_for('dashboard'))
            except Exception as e:
                flash(f'Error processing manual data: {e}', 'danger')
                return redirect(url_for('dashboard'))
        else:
            flash('Please upload a CSV or enter manual student data.', 'warning')
            return redirect(url_for('dashboard'))

        df, class_avg, pass_count, fail_count, top_students, top_scorer = analyze_data(df)
        charts = create_charts(df)
        table_html = df.to_html(classes='table table-striped table-bordered', index=False)

    return render_template('index.html',
                           table=table_html,
                           top_scorer=top_scorer,
                           top_n=top_students,
                           charts=charts,
                           pass_count=pass_count,
                           fail_count=fail_count)


@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    flash('Logged out successfully.', 'info')
    return redirect(url_for('login'))


if __name__ == '__main__':
    app.run(debug=True, port=5002)
